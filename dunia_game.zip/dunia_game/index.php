<html>
<head>
	<title> INDGame</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
	<script type="text/javascript" src="jquery.js"></script>
	<script type="text/javascript" src="slide.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
	
		currentSlide(1);
		
		setInterval(function() {
			$(".next").click();
		}, 5000); 
	
		});
	</script>
</head>

<body>
	<div class="header" >
		<div id="logo">
			<div class="container">
				<a href="index.html"><span>IND</span>Game</a>
			</div>
		</div>
	</div>
	
	<div id="menu">
		<div class="container">
			<ul id="kiri">
				<li> <a href="index.html">BERANDA</a></li>
				<li> <a href="game.html">GAME</a></li>
				<li> <a href="news.html">BERITA</a></li>
				<li> <a href="about.html">TENTANG</a></li>
			</ul>
			<ul id="kanan">
				<li><a href="http://facebook.com"><img src="image/facebook.png" width="24px"></a></li>
				<li><a href="http://twitter.com"><img src="image/twitter.png" width="24px"></a></li>
				<li><a href="http://instagram.com"><img src="image/instagram.png" width="24px"></a></li>
			</ul>
		</div>
	</div>
	
	<div class="content">
		<div class="container">
			 <!-- Slideshow container -->
	<div class="slideshow-container">

  <!-- Full-width images with number and caption text -->
		<div class="mySlides fade">
		<div class="numbertext">1 / 3</div>
		<a href="detail.html"><img src="image/game1ss.png" style="width:100%; height:500px; padding:10px; padding-bottom:0px"></a>
		<div class="text"><a href="detail.html">Watch Dogs : Hacker Penguasa Kota</a></div>
	</div>

	<div class="mySlides fade">
		<div class="numbertext">2 / 3</div>
		<a href="detail2.html"><img src="image/game2ss.png" style="width:100%; height:500px; padding:10px; padding-bottom:0px"></a>
		<div class="text"><a href="detail2.html">Assassin's Creed Origins : Seri Baru dari Ubisoft</a></div>
	</div>

	<div class="mySlides fade">
		<div class="numbertext">3 / 3</div>
		<a href="detail.html"><img src="image/game3ss.jpg" style="width:100%; height:500px; padding:10px; padding-bottom:0px"></a>
		<div class="text"><a href="detail.html">Far Cry Primal : Menguasai / Dikuasai</a></div>
	</div>

  <!-- <- & -> -->
	<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
	<a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>
<br>

<!-- Titik -->
<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span>
  <span class="dot" onclick="currentSlide(2)"></span>
  <span class="dot" onclick="currentSlide(3)"></span>
  
</div> 
			<div id="kiri">
				<div class="post">
					<a href="detail.html"><img src="image/game1.png"></a>
					<h3><a href="detail.html">Watch Dogs : Hacker Penguasa Kota</a></h3>
					<p>
					<span style="color: orange;">Judul</span>: Watch Dogs<br>
					<span style="color: orange;">Genre</span>: Action, Adventure<br>
					<span style="color: orange;">Pengembang</span>: Ubisoft<br>
					<span style="color: orange;">Penerbit</span>: Ubisoft<br>
					<span style="color: orange;">Tanggal Rilis</span>: 27 May, 2014<br>
					<span style="color: orange;">Bahasa</span>: English, French, Italian, German, Spanish, Etc. . .</p>
					<p> Watch Dogs bercerita tentang kisah Aiden Pearce. Seorang kriminal yang melancarkan 
					aksinya dengan memanfaatkan infrastruktur kota yang disebut ctOS. Dengan melakukan hack pada ctOS, Aiden dapat. . .</p>
					<a href="detail.html" class="tombol">Baca Selengkapnya &rarr;</a>
				</div>
				
				<div class="post">
					<a href="detail2.html"><img src="image/news1.jpg"></a>
					<h3><a href="detail2.html">Assassin's Creed Origins : Seri Baru Dari Ubisoft</a></h3>
					<p>
					<span style="color: orange;">Judul</span>: Assassin's Creed Origins<br>
					<span style="color: orange;">Genre</span>: Action, Adventure<br>
					<span style="color: orange;">Pengembang</span>: Ubisoft<br>
					<span style="color: orange;">Penerbit</span>: Ubisoft<br>
					<span style="color: orange;">Tanggal Rilis</span>: 27 Oktober, 2017<br>
					<span style="color: orange;">Bahasa</span>: English, French, Italian, German, Spanish, Etc. . .
					</p>
					<p> Salah satu mekanik terbaik yang pernah "dilahirkan" oleh Assassin's Creed 
					sebagai sebuah franchise, sepertinya bukan ungkapan berlebihan untuk memuji skema pertempuran kapal yang ia tawarkan.</p>
					<a href="detail2.html" class="tombol">Baca Selengkapnya &rarr;</a>
				</div>	
				
				<div class="post">
					<a href="detail.html"><img src="image/game2.jpg"></a>
					<h3><a href="detail.html">Far Cry Primal : Menguasai / Dikuasai</a></h3>
					<p>
					<span style="color: orange;">Judul</span>: Far Cry Primal<br>
					<span style="color: orange;">Genre</span>: Action, Adventure<br>
					<span style="color: orange;">Pengembang</span>: Ubisoft<br>
					<span style="color: orange;">Penerbit</span>: Ubisoft<br>
					<span style="color: orange;">Tanggal Rilis</span>: 1 Mar, 2016<br>
					<span style="color: orange;">Bahasa</span>: English, French, Italian, German, Spanish, Etc. . .
					</p>
					<p> Far Cry Primal akan membawa Anda pada kehidupan manusia ditahun 10.000 sebelum Masehi, 
					dimana teknologi masih berkisar pada usaha untuk memanipulasi bentuk batu dan kayu untuk tujuan bertahan hidup.</p>
					<a href="detail.html" class="tombol">Baca Selengkapnya &rarr;</a>
				</div>
				
				<div class="post">
					<a href="detail2.html"><img src="image/news2.jpg"></a>
					<h3><a href="detail2.html">Spider-Man PS4 : Gameplay Menawan</a></h3>
					<p>
					<span style="color: orange;">Judul</span>: Spider-Man<br>
					<span style="color: orange;">Genre</span>: Action, Adventure<br>
					<span style="color: orange;">Pengembang</span>: Insomniac<br>
					<span style="color: orange;">Penerbit</span>: SIEA<br>
					<span style="color: orange;">Tanggal Rilis</span>: 2018<br>
					<span style="color: orange;">Bahasa</span>: English, French, Italian, German, Spanish, Etc. . .
					</p>
					<p> Selesai sudah penantian para penggemar game Marvel, khususnya Spider-Man, 
					yang kini sudah bisa menyaksikan bagaimana aksi si manusia laba-laba dalam game terbarunya untuk konsol PlayStation 4 nanti. . .</p>
					<a href="detail2.html" class="tombol">Baca Selengkapnya &rarr;</a>
				</div>
				
				<div class="post">
					<a href="detail2.html"><img src="image/news3.jpg"></a>
					<h3><a href="detail2.html">Red Dead Redemption 2 PS4</a></h3>
					<p>
					<span style="color: orange;">Judul</span>: Red Dead Redemption 2<br>
					<span style="color: orange;">Genre</span>: Action, Adventure<br>
					<span style="color: orange;">Pengembang</span>: Rockstar Games<br>
					<span style="color: orange;">Penerbit</span>: Rockstar Games<br>
					<span style="color: orange;">Tanggal Rilis</span>: 2018<br>
					<span style="color: orange;">Bahasa</span>: English, French, Italian, German, Spanish, Etc. . .
					</p>
					<p> Trailer Red Dead Redemption 2 akhirnya dikeluarkan juga oleh Rockstar, 
					setelah penantian panjang. Walau menampilkan dunia koboi yang jauh lebih berwarna dan hidup, trailer ini masih memberikan tanda tanya. . .</p>
					<a href="detail2.html" class="tombol">Baca Selengkapnya &rarr;</a>
				</div>
				
				<div class="post">
					<a href="detail.html"><img src="image/game3.jpg"></a>
					<h3><a href="detail.html">Sniper Elite 3: Bidikan yang Sempurna</a></h3>
					<p>
					<span style="color: orange;">Judul</span>: Sniper Elite 3<br>
					<span style="color: orange;">Genre</span>: Action, Adventure, Shooter<br>
					<span style="color: orange;">Pengembang</span>: Rebellion<br>
					<span style="color: orange;">Penerbit</span>: Rebellion<br>
					<span style="color: orange;">Tanggal Rilis</span>: July 1, 2014<br>
					<span style="color: orange;">Bahasa</span>: English, French, Italian, German, Spanish, Etc. . .
					</p>
					<p> Remake Sniper Elite yang dirilis Mei 2012 lalu, Sniper Elite V2, 
					sudah cukup membuat game shooter yang terfokus pada keahlian membidik dari jarak jauh dan aksi stealth tersebut kembali diterima penggemarnya. . .</p>
					<a href="detail.html" class="tombol">Baca Selengkapnya &rarr;</a>
				</div>
			</div>
			
			<div id="kanan">
				<div class="kotak">
					<form action="index.html" method="get">
					<input type="text" name="cari" placeholder="Cari. . .">
				</div>
				<div class="kotak" style="margin-top: 20px;">
					<div class="kotakatas">
					Postingan Populer
					</div>
					
					<div class="kotakcontent">
						<ul class="popular">
							<li> <a href="detail.html">
							<img src="image/popular1.png"></a>
							<h5><a href="detail.html">Watch Dogs : Hacker Penguasa Kota</a></h5>
							</li>
						</ul>
						
						<ul class="popular">
							<li> <a href="detail2.html">
							<img src="image/popular2.png"></a>
							<h5><a href="detail2.html">Assassin's Creed Origins : Seri Baru. .</a></h5>
							</li>
						</ul>
						
						<ul class="popular">
							<li> <a href="detail2.html">
							<img src="image/popular3.png"></a>
							<h5><a href="detail2.html">Spider-Man PS4:Gameplay Menawan</a></h5>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="footer">
		<div class="container">
			Copyright &copy; 2017
			Designed by Zamharir
		</div> 
	</div>
</body>
</html>